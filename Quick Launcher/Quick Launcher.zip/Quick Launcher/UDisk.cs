﻿namespace Quick_Launcher
{
    internal class UDisk
    {
        internal string Letter;
        internal string Name;
        internal string Size;

        internal UDisk(string letter, string name, string size)
        {
            Letter = letter;
            Name = name;
            Size = size;
        }
    }
}